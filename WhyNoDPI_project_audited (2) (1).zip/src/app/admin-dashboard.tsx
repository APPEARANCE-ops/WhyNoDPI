"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  Users,
  UserPlus,
  Clock3,
  RefreshCw,
  LogOut,
  Trash2,
  ShieldCheck,
  Loader2,
  MonitorSmartphone,
} from "lucide-react";

type Stats = {
  serverTime: string;
  onlineWindowSeconds: number;
  online: number;
  total: number;
  newToday: number;
  active24h: number;
  versions: { name: string; count: number }[];
  oses: { name: string; count: number }[];
  strategies: { name: string; count: number }[];
  recent: {
    idMasked: string;
    firstSeenAt: string;
    lastSeenAt: string;
    online: boolean;
    appVersion: string;
    osInfo: string;
    strategy: string;
  }[];
  trend: { t: number; online: number }[];
};

const REFRESH_MS = 10_000;

function fmtRelative(iso: string, nowMs: number): string {
  const diff = Math.max(0, nowMs - new Date(iso).getTime());
  const s = Math.floor(diff / 1000);
  if (s < 15) return "только что";
  if (s < 60) return `${s} с назад`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} мин назад`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ч ${m % 60} мин назад`;
  const d = Math.floor(h / 24);
  return `${d} дн назад`;
}

function fmtClock(iso: string): string {
  return new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function BreakdownList({ items, emptyText }: { items: { name: string; count: number }[]; emptyText: string }) {
  if (items.length === 0) {
    return <p className="text-sm text-zinc-500">{emptyText}</p>;
  }
  const max = Math.max(...items.map((i) => i.count), 1);
  return (
    <ul className="space-y-2">
      {items.map((item) => (
        <li key={item.name}>
          <div className="flex items-center justify-between gap-2 text-sm">
            <span className="truncate text-zinc-300" title={item.name}>
              {item.name}
            </span>
            <span className="shrink-0 tabular-nums text-zinc-400">{item.count}</span>
          </div>
          <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-zinc-800">
            <div
              className="h-full rounded-full bg-emerald-500/70"
              style={{ width: `${Math.max(4, (item.count / max) * 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [auto, setAuto] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<number | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [resetting, setResetting] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const autoRef = useRef(auto);
  autoRef.current = auto;

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/stats", {
        credentials: "same-origin",
        cache: "no-store",
      });
      if (res.status === 401) {
        router.refresh();
        return;
      }
      const data = (await res.json()) as { ok?: boolean; stats?: Stats };
      if (res.ok && data.ok && data.stats) {
        setStats(data.stats);
        setError(null);
        setLastUpdate(Date.now());
      } else {
        setError("Не удалось получить статистику.");
      }
    } catch {
      setError("Сеть недоступна. Пробуем снова…");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!auto) return;
    const id = setInterval(() => {
      if (document.visibilityState === "visible") load();
    }, REFRESH_MS);
    return () => clearInterval(id);
  }, [auto, load]);

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST", credentials: "same-origin" }).catch(
      () => undefined
    );
    router.refresh();
  }

  async function resetData() {
    setResetting(true);
    try {
      await fetch("/api/admin/reset", { method: "POST", credentials: "same-origin" });
      await load();
    } finally {
      setResetting(false);
      setConfirmText("");
    }
  }

  const trendData = (stats?.trend ?? []).map((p) => ({
    ...p,
    label: new Date(p.t).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }),
  }));

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur supports-[backdrop-filter]:bg-zinc-950/75">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/10 border border-emerald-500/30">
              <ShieldCheck className="h-5 w-5 text-emerald-400" aria-hidden="true" />
            </div>
            <div>
              <h1 className="text-sm font-semibold leading-tight sm:text-base">
                WhyNoDPI · Админ-панель
              </h1>
              <p className="text-xs text-zinc-500 leading-tight">
                Серверное время: {lastUpdate ? fmtClock(new Date(lastUpdate).toISOString()) : "—"}
              </p>
            </div>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Switch
                id="auto-refresh"
                checked={auto}
                onCheckedChange={setAuto}
                aria-label="Автообновление каждые 10 секунд"
              />
              <Label htmlFor="auto-refresh" className="text-xs text-zinc-400">
                Авто 10 с
              </Label>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => load()}
              className="border-zinc-800 bg-zinc-900 hover:bg-zinc-800 hover:text-zinc-100"
              aria-label="Обновить статистику"
            >
              <RefreshCw className="h-4 w-4" aria-hidden="true" />
              <span className="ml-1.5 hidden sm:inline">Обновить</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={logout}
              className="border-zinc-800 bg-zinc-900 hover:bg-zinc-800 hover:text-zinc-100"
              aria-label="Выйти из админ-панели"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
              <span className="ml-1.5 hidden sm:inline">Выйти</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">
        {loading && (
          <div className="flex items-center justify-center py-24 text-zinc-500" role="status">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden="true" />
            Загрузка статистики…
          </div>
        )}

        {!loading && error && !stats && (
          <Card className="bg-zinc-900/80 border-zinc-800">
            <CardContent className="flex items-center gap-3 p-6 text-sm text-red-300">
              <span role="alert">{error}</span>
              <Button size="sm" variant="outline" onClick={load} className="ml-auto border-zinc-800">
                Повторить
              </Button>
            </CardContent>
          </Card>
        )}

        {!loading && stats && (
          <div className="space-y-6">
            {error && stats && (
              <p role="alert" className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-300">
                {error} Показаны последние полученные данные.
              </p>
            )}

            {/* Stat cards */}
            <section aria-label="Ключевые показатели" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <Card className="bg-gradient-to-br from-emerald-950/60 to-zinc-900 border-emerald-800/40">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center gap-2 text-emerald-300/90">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                      <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
                    </span>
                    В сети сейчас
                  </CardDescription>
                  <CardTitle className="text-4xl font-bold tabular-nums text-emerald-300">
                    {stats.online}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-zinc-500">
                  Окно онлайна: {stats.onlineWindowSeconds} с после последнего heartbeat
                </CardContent>
              </Card>

              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center gap-2 text-zinc-400">
                    <Users className="h-4 w-4" aria-hidden="true" />
                    Всего пользователей
                  </CardDescription>
                  <CardTitle className="text-4xl font-bold tabular-nums">{stats.total}</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-zinc-500">
                  Уникальных установок за всё время
                </CardContent>
              </Card>

              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center gap-2 text-zinc-400">
                    <UserPlus className="h-4 w-4" aria-hidden="true" />
                    Новые сегодня
                  </CardDescription>
                  <CardTitle className="text-4xl font-bold tabular-nums">{stats.newToday}</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-zinc-500">
                  Первое подключение с начала суток
                </CardContent>
              </Card>

              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-2">
                  <CardDescription className="flex items-center gap-2 text-zinc-400">
                    <Clock3 className="h-4 w-4" aria-hidden="true" />
                    Активны за 24 часа
                  </CardDescription>
                  <CardTitle className="text-4xl font-bold tabular-nums">{stats.active24h}</CardTitle>
                </CardHeader>
                <CardContent className="text-xs text-zinc-500">
                  Хотя бы один heartbeat за сутки
                </CardContent>
              </Card>
            </section>

            {/* Trend chart */}
            <Card className="bg-zinc-900/80 border-zinc-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Activity className="h-4 w-4 text-emerald-400" aria-hidden="true" />
                  Пользователи в сети за 24 часа
                </CardTitle>
                <CardDescription>
                  Среднее число онлайн-клиентов по 15-минутным интервалам · обновляется
                  автоматически
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trendData} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
                      <defs>
                        <linearGradient id="onlineFill" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity={0.45} />
                          <stop offset="100%" stopColor="#10b981" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="#27272a" strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="label"
                        tick={{ fill: "#71717a", fontSize: 11 }}
                        tickLine={false}
                        axisLine={{ stroke: "#3f3f46" }}
                        minTickGap={28}
                      />
                      <YAxis
                        tick={{ fill: "#71717a", fontSize: 11 }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip
                        contentStyle={{
                          background: "#18181b",
                          border: "1px solid #3f3f46",
                          borderRadius: 8,
                          color: "#e4e4e7",
                          fontSize: 12,
                        }}
                        labelStyle={{ color: "#a1a1aa" }}
                        formatter={(value: number) => [value, "В сети"]}
                      />
                      <Area
                        type="monotone"
                        dataKey="online"
                        stroke="#10b981"
                        strokeWidth={2}
                        fill="url(#onlineFill)"
                        isAnimationActive={false}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Breakdowns */}
            <section aria-label="Распределения" className="grid grid-cols-1 gap-4 lg:grid-cols-3">
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-zinc-300">Версии приложения</CardTitle>
                </CardHeader>
                <CardContent>
                  <BreakdownList items={stats.versions} emptyText="Данных пока нет" />
                </CardContent>
              </Card>
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm font-medium text-zinc-300">
                    <MonitorSmartphone className="h-4 w-4" aria-hidden="true" />
                    Операционные системы
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <BreakdownList items={stats.oses} emptyText="Данных пока нет" />
                </CardContent>
              </Card>
              <Card className="bg-zinc-900/80 border-zinc-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-zinc-300">Активные стратегии</CardTitle>
                </CardHeader>
                <CardContent>
                  <BreakdownList items={stats.strategies} emptyText="Данных пока нет" />
                </CardContent>
              </Card>
            </section>

            {/* Recent clients */}
            <Card className="bg-zinc-900/80 border-zinc-800">
              <CardHeader>
                <CardTitle className="text-base">Последние клиенты</CardTitle>
                <CardDescription>
                  Идентификаторы анонимизированы (первые символы хеша). Личные данные не
                  собираются и не хранятся.
                </CardDescription>
              </CardHeader>
              <CardContent className="max-h-96 overflow-y-auto">
                {stats.recent.length === 0 ? (
                  <p className="py-8 text-center text-sm text-zinc-500">
                    Пока нет ни одного клиента. Запустите WhyNoDPI с включённой телеметрией —
                    здесь появятся данные.
                  </p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow className="border-zinc-800 hover:bg-transparent">
                        <TableHead className="text-zinc-400">Клиент</TableHead>
                        <TableHead className="text-zinc-400">Версия</TableHead>
                        <TableHead className="text-zinc-400">ОС</TableHead>
                        <TableHead className="text-zinc-400">Стратегия</TableHead>
                        <TableHead className="text-zinc-400">Статус</TableHead>
                        <TableHead className="text-right text-zinc-400">Активность</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stats.recent.map((c) => (
                        <TableRow key={c.idMasked} className="border-zinc-800/70">
                          <TableCell className="font-mono text-xs text-zinc-300">{c.idMasked}…</TableCell>
                          <TableCell className="text-sm text-zinc-300">{c.appVersion}</TableCell>
                          <TableCell className="text-sm text-zinc-400">{c.osInfo}</TableCell>
                          <TableCell className="max-w-40 truncate text-sm text-zinc-400" title={c.strategy}>
                            {c.strategy}
                          </TableCell>
                          <TableCell>
                            {c.online ? (
                              <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/15">
                                в сети
                              </Badge>
                            ) : (
                              <Badge
                                variant="outline"
                                className="border-zinc-700 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300"
                              >
                                офлайн
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right text-sm text-zinc-400" title={fmtClock(c.lastSeenAt)}>
                            {fmtRelative(c.lastSeenAt, nowMs)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            {/* Danger zone */}
            <Card className="border-red-900/50 bg-red-950/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-red-300">Опасная зона</CardTitle>
                <CardDescription className="text-zinc-400">
                  Полная очистка телеметрии: удалит всех клиентов, историю онлайна и начнёт
                  сбор заново. Журнал аудита сохраняется.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="border-red-800/60 bg-red-950/40 text-red-300 hover:bg-red-900/40 hover:text-red-200"
                    >
                      <Trash2 className="mr-2 h-4 w-4" aria-hidden="true" />
                      Очистить все данные
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-zinc-900 border-zinc-800 text-zinc-100">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Удалить всю телеметрию?</AlertDialogTitle>
                      <AlertDialogDescription className="text-zinc-400">
                        Будут удалены все клиенты и история онлайна. Действие необратимо.
                        Для подтверждения введите слово{" "}
                        <span className="font-mono text-red-300">УДАЛИТЬ</span>.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <Input
                      value={confirmText}
                      onChange={(e) => setConfirmText(e.target.value)}
                      placeholder="УДАЛИТЬ"
                      className="bg-zinc-950 border-zinc-800"
                      aria-label="Подтверждение удаления"
                    />
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-transparent border-zinc-800 text-zinc-300 hover:bg-zinc-800 hover:text-zinc-100">
                        Отмена
                      </AlertDialogCancel>
                      <AlertDialogAction
                        disabled={confirmText !== "УДАЛИТЬ" || resetting}
                        onClick={(e) => {
                          e.preventDefault();
                          resetData();
                        }}
                        className="bg-red-700 hover:bg-red-600 text-white"
                      >
                        {resetting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                            Удаление…
                          </>
                        ) : (
                          "Да, удалить всё"
                        )}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      <footer className="mt-auto border-t border-zinc-800 py-4">
        <div className="mx-auto max-w-6xl px-4 text-center text-xs text-zinc-600 sm:px-6">
          WhyNoDPI telemetry · heartbeat каждые 60 с · данные хранятся анонимно · сессия
          администратора шифруется httpOnly-cookie и истекает автоматически
        </div>
      </footer>
    </div>
  );
}
