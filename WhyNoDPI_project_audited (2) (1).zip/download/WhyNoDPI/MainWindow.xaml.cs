using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NoDPI.Core;

namespace NoDPI;

public partial class MainWindow : Window
{
    private bool isLoadingSettings = true;
    private bool allowClose;
    private readonly EngineManager engineManager = new();
    private readonly SettingsManager settings = new();
    private readonly StartupManager startupManager = new();
    private readonly NetworkDiagnostics diagnostics = new();
    private readonly TelemetryClient telemetry = new();

    public MainWindow()
    {
        InitializeComponent();
        engineManager.StatusChanged += message => Dispatcher.InvokeAsync(() =>
        {
            AddLog(message);
            ModuleStatus.Text = message;
            if (message.StartsWith("Подготовка профиля", StringComparison.OrdinalIgnoreCase))
                StatusText.Text = "Запуск...";
            UpdateEngineUi();
        });
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            settings.Load();
        }
        catch (Exception ex)
        {
            AddLog("Не удалось загрузить настройки: " + ex.Message);
        }

        try
        {
            startupManager.SetEnabled(settings.AutoStart);
        }
        catch (Exception ex)
        {
            AddLog("Не удалось применить автозапуск: " + ex.Message);
        }

        AutoStartBox.IsChecked = settings.AutoStart;
        TelemetryBox.IsChecked = settings.TelemetryEnabled;
        telemetry.CurrentStrategy = settings.ZapretStrategyFile;
        if (settings.TelemetryEnabled)
            telemetry.Start(settings.ZapretStrategyFile);
        if (!string.IsNullOrWhiteSpace(settings.ZapretDirectory) && Directory.Exists(settings.ZapretDirectory))
        {
            try
            {
                string resolvedRoot = EngineManager.ResolveBundleRoot(settings.ZapretDirectory);
                if (!string.Equals(resolvedRoot, settings.ZapretDirectory, StringComparison.OrdinalIgnoreCase))
                {
                    settings.ZapretDirectory = resolvedRoot;
                    SaveSettings();
                    AddLog("Автоматически найдена вложенная папка пакета Flowseal: " + resolvedRoot);
                }
            }
            catch (Exception ex)
            {
                AddLog("Сохранённый путь Flowseal пока не прошёл проверку: " + ex.Message);
            }
        }

        engineManager.Configure(settings.ZapretDirectory);
        LoadStrategies(settings.ZapretStrategyFile);
        isLoadingSettings = false;

        AddLog("WhyNoDPI готов к работе.");
        AddLog("Выберите пакет Flowseal в настройках, затем запустите или проверьте стратегии.");
        UpdateEngineUi();

        if (engineManager.RefreshStatus())
            AddLog("Обнаружен уже работающий winws.exe из выбранной папки Flowseal.");

        await Task.CompletedTask;
    }

    private void LoadStrategies(string preferredFile)
    {
        isLoadingSettings = true;
        StrategyBox.Items.Clear();
        HomeStrategyBox.Items.Clear();

        if (string.IsNullOrWhiteSpace(settings.ZapretDirectory) || !Directory.Exists(settings.ZapretDirectory))
        {
            AddStrategyPlaceholder("Пакет Flowseal не выбран");
            CurrentStrategy.Text = "Не выбран";
            ActiveProfileFileText.Text = "General";
            ProfileCountText.Text = "Профили не найдены";
            StrategyDescription.Text = "В настройках выберите корневую папку распакованного пакета Flowseal.";
            ZapretPathText.Text = "Папка Flowseal не выбрана.";
            isLoadingSettings = false;
            return;
        }

        IReadOnlyList<string> profiles = StrategyManager.FindProfiles(settings.ZapretDirectory);
        ZapretPathText.Text = settings.ZapretDirectory;
        ProfileCountText.Text = $"Найдено профилей: {profiles.Count}";

        if (profiles.Count == 0)
        {
            AddStrategyPlaceholder("Профили General не найдены");
            CurrentStrategy.Text = "Нет профилей";
            ActiveProfileFileText.Text = "General";
            StrategyDescription.Text = "Проверьте, что выбрана папка Flowseal с профилями General, bin\\winws.exe и списками.";
            isLoadingSettings = false;
            return;
        }

        PopulateStrategyBox(StrategyBox, profiles, preferredFile);
        PopulateStrategyBox(HomeStrategyBox, profiles, preferredFile);

        ComboBoxItem? selected = StrategyBox.SelectedItem as ComboBoxItem;
        if (selected?.Tag is string selectedFile)
        {
            settings.ZapretStrategyFile = selectedFile;
            CurrentStrategy.Text = StrategyManager.DisplayName(selectedFile);
            ActiveProfileFileText.Text = Path.GetFileNameWithoutExtension(selectedFile);
            StrategyDescription.Text = "Профиль Flowseal: " + StrategyManager.DisplayName(selectedFile) + ". Его параметры будут переданы прямо в winws.exe.";
        }
        isLoadingSettings = false;
    }

    private void AddStrategyPlaceholder(string label)
    {
        StrategyBox.Items.Add(new ComboBoxItem { Content = label, IsEnabled = false });
        HomeStrategyBox.Items.Add(new ComboBoxItem { Content = label, IsEnabled = false });
        StrategyBox.SelectedIndex = 0;
        HomeStrategyBox.SelectedIndex = 0;
    }

    private static void PopulateStrategyBox(ComboBox box, IReadOnlyList<string> profiles, string preferredFile)
    {
        foreach (string fileName in profiles)
        {
            box.Items.Add(new ComboBoxItem
            {
                Content = StrategyManager.DisplayName(fileName),
                Tag = fileName
            });
        }

        ComboBoxItem? selected = box.Items.OfType<ComboBoxItem>()
            .FirstOrDefault(item => string.Equals(item.Tag as string, preferredFile, StringComparison.OrdinalIgnoreCase));
        box.SelectedItem = selected ?? box.Items.OfType<ComboBoxItem>().FirstOrDefault();
    }

    private void UpdateEngineUi()
    {
        bool ownedRunning = engineManager.RefreshStatus();
        bool serviceRunning = engineManager.IsZapretServiceRunning;
        bool externalWinws = !ownedRunning && engineManager.IsAnyWinwsProcessRunning;
        bool protectedTraffic = ownedRunning || serviceRunning || externalWinws;
        bool externallyManaged = serviceRunning || (externalWinws && !ownedRunning);

        StrategyBox.IsEnabled = !protectedTraffic;
        HomeStrategyBox.IsEnabled = !protectedTraffic;
        if (StartSelectedStrategyButton is not null)
            StartSelectedStrategyButton.IsEnabled = !protectedTraffic;
        if (StopEngineButton is not null)
            StopEngineButton.IsEnabled = ownedRunning && !serviceRunning;
        AutoDetectButton.IsEnabled = !protectedTraffic;
        AutoDetectButtonHome.IsEnabled = !protectedTraffic;
        ToggleButton.IsEnabled = !externallyManaged;

        ToggleButton.Content = externallyManaged
            ? (serviceRunning ? "Zapret работает как служба" : "Найден внешний Zapret")
            : ownedRunning ? "Остановить Zapret" : "Включить Zapret";
        ToggleButton.Background = protectedTraffic
            ? new SolidColorBrush(Color.FromRgb(185, 65, 78))
            : new SolidColorBrush(Color.FromRgb(55, 120, 246));
        StatusText.Text = serviceRunning ? "Служба Zapret включена" :
            externalWinws ? "Обнаружен внешний движок" :
            ownedRunning ? "Движок включён" : "Движок выключен";
        StatusDot.Fill = protectedTraffic ? Brushes.MediumSeaGreen : Brushes.Gray;
        SidebarStatusDot.Fill = protectedTraffic ? Brushes.MediumSeaGreen : Brushes.Gray;
        SidebarStatusText.Text = serviceRunning ? "Работает служба Flowseal" :
            externalWinws ? "Работает внешний winws.exe" :
            ownedRunning ? "Движок работает" : "Движок выключен";
        SidebarStatusText.Foreground = protectedTraffic
            ? new SolidColorBrush(Color.FromRgb(89, 211, 164))
            : new SolidColorBrush(Color.FromRgb(145, 160, 184));

        string activeFile = engineManager.ActiveStrategyFile ?? settings.ZapretStrategyFile;
        CurrentStrategy.Text = string.IsNullOrWhiteSpace(activeFile) ? "Не выбран" : StrategyManager.DisplayName(activeFile);
        ActiveProfileFileText.Text = string.IsNullOrWhiteSpace(activeFile) ? "General" : Path.GetFileNameWithoutExtension(activeFile);

        if (serviceRunning)
            ModuleStatus.Text = "Уже запущена служба Windows «zapret». Сначала остановите её через средство управления Flowseal.";
        else if (externalWinws)
            ModuleStatus.Text = "Обнаружен winws.exe из другого расположения. Остановите предыдущий Zapret, прежде чем запускать профиль из WhyNoDPI.";
        else if (ownedRunning)
            ModuleStatus.Text = "winws.exe запущен напрямую. Командные файлы не запускаются.";
        else if (string.IsNullOrWhiteSpace(settings.ZapretDirectory))
            ModuleStatus.Text = "Сначала выберите папку Flowseal в настройках.";
        else
            ModuleStatus.Text = "Готов к запуску выбранного профиля.";
    }

    private void ShowPage(Grid page, string name)
    {
        HomePage.Visibility = Visibility.Collapsed;
        StrategiesPage.Visibility = Visibility.Collapsed;
        TelegramToolsPage.Visibility = Visibility.Collapsed;
        JournalPage.Visibility = Visibility.Collapsed;
        SettingsPage.Visibility = Visibility.Collapsed;
        page.Visibility = Visibility.Visible;
        AddLog("Открыта страница: " + name);
    }

    private void Home_Click(object sender, RoutedEventArgs e) => ShowPage(HomePage, "Главная");
    private void Strategies_Click(object sender, RoutedEventArgs e) => ShowPage(StrategiesPage, "Стратегии");
    private void TelegramTools_Click(object sender, RoutedEventArgs e) => ShowPage(TelegramToolsPage, "Telegram / VPN");
    private void Journal_Click(object sender, RoutedEventArgs e) => ShowPage(JournalPage, "Журнал");
    private void Settings_Click(object sender, RoutedEventArgs e) => ShowPage(SettingsPage, "Настройки");

    private async void ToggleButton_Click(object sender, RoutedEventArgs e)
    {
        ToggleButton.IsEnabled = false;
        try
        {
            if (engineManager.IsZapretServiceRunning || (!engineManager.RefreshStatus() && engineManager.IsAnyWinwsProcessRunning))
            {
                MessageBox.Show(
                    "Обнаружен уже работающий Zapret, запущенный не этим окном. WhyNoDPI не будет останавливать чужой процесс. Остановите его штатным способом и повторите попытку.",
                    "Zapret уже работает", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (engineManager.RefreshStatus())
            {
                await engineManager.StopAsync();
                YoutubeStatus.Text = "Движок выключен.";
                DiscordStatus.Text = "Движок выключен.";
                TelegramStatus.Text = "Движок выключен.";
            }
            else
            {
                await StartSelectedAsync();
            }
        }
        catch (Exception ex)
        {
            AddLog("Ошибка движка: " + ex.Message);
            MessageBox.Show(ex.Message, "WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            UpdateEngineUi();
        }
    }

    private async Task<bool> StartSelectedAsync()
    {
        if (engineManager.IsZapretServiceRunning || (!engineManager.RefreshStatus() && engineManager.IsAnyWinwsProcessRunning))
        {
            MessageBox.Show(
                "Сейчас уже работает другой экземпляр Zapret. Остановите его через исходный пакет Flowseal, затем запускайте General из WhyNoDPI.",
                "Zapret уже работает", MessageBoxButton.OK, MessageBoxImage.Information);
            return false;
        }

        if (string.IsNullOrWhiteSpace(settings.ZapretDirectory))
        {
            MessageBox.Show("Сначала выберите папку Flowseal в разделе «Настройки».", "Пакет не выбран",
                MessageBoxButton.OK, MessageBoxImage.Information);
            ShowPage(SettingsPage, "Настройки");
            return false;
        }

        bool started = await engineManager.StartAsync(settings.ZapretDirectory, settings.ZapretStrategyFile);
        if (started)
        {
            await Task.Delay(900);
            await CheckCurrentServicesAsync();
        }
        else
        {
            string reason = engineManager.LastFailureMessage ?? "Не удалось запустить выбранный профиль. Откройте журнал и запустите диагностику пакета.";
            AddLog("Запуск General не выполнен: " + reason);
            MessageBox.Show(
                reason + (string.IsNullOrWhiteSpace(engineManager.LastLogPath) ? string.Empty : "\n\nЖурнал: " + engineManager.LastLogPath),
                "Не удалось запустить Zapret", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        UpdateEngineUi();
        return started;
    }

    private async void StartSelectedStrategy_Click(object sender, RoutedEventArgs e)
    {
        await RunUiActionAsync(async () =>
        {
            if (engineManager.IsZapretServiceRunning || (!engineManager.RefreshStatus() && engineManager.IsAnyWinwsProcessRunning))
            {
                MessageBox.Show("Сначала остановите внешний Zapret или службу Flowseal. WhyNoDPI не должен перезапускать чужой winws.exe.",
                    "Zapret уже работает", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (engineManager.RefreshStatus())
                await engineManager.StopAsync();
            await StartSelectedAsync();
        });
    }

    private async void StopEngine_Click(object sender, RoutedEventArgs e)
    {
        if (engineManager.IsZapretServiceRunning)
        {
            MessageBox.Show("Zapret запущен как служба Windows. Остановите её через средство управления Flowseal.",
                "Служба Flowseal", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        await RunUiActionAsync(async () => await engineManager.StopAsync());
    }

    private async Task RunUiActionAsync(Func<Task> action)
    {
        SetActionButtonsEnabled(false);
        try { await action(); }
        catch (Exception ex)
        {
            AddLog("Ошибка: " + ex.Message);
            MessageBox.Show(ex.Message, "WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            SetActionButtonsEnabled(true);
            UpdateEngineUi();
        }
    }

    private void SetActionButtonsEnabled(bool enabled)
    {
        ToggleButton.IsEnabled = enabled;
        AutoDetectButton.IsEnabled = enabled;
        AutoDetectButtonHome.IsEnabled = enabled;
        StartSelectedStrategyButton.IsEnabled = enabled;
        StopEngineButton.IsEnabled = enabled;
    }

    private async void AutoDetectButton_Click(object sender, RoutedEventArgs e)
    {
        ShowPage(StrategiesPage, "Стратегии");
        SetActionButtonsEnabled(false);
        StrategyBox.IsEnabled = false;
        HomeStrategyBox.IsEnabled = false;
        TestResultsList.Items.Clear();
        TestProgressBar.Value = 0;
        TestProgressText.Text = "Подготовка...";
        YoutubeStatus.Text = "Идёт проверка стратегий...";
        DiscordStatus.Text = "Идёт проверка стратегий...";
        TelegramStatus.Text = "Идёт проверка стратегий...";

        try
        {
            if (string.IsNullOrWhiteSpace(settings.ZapretDirectory) || !Directory.Exists(settings.ZapretDirectory))
            {
                MessageBox.Show("Сначала выберите распакованную папку Flowseal в настройках.", "Папка не выбрана",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                ShowPage(SettingsPage, "Настройки");
                return;
            }

            if (engineManager.IsZapretServiceRunning || (!engineManager.RefreshStatus() && engineManager.IsAnyWinwsProcessRunning))
            {
                MessageBox.Show("Сначала остановите уже работающий Zapret вне WhyNoDPI. Автоподбор не должен запускать несколько движков одновременно.",
                    "Zapret уже работает", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            IReadOnlyList<string> profiles = StrategyManager.FindProfiles(settings.ZapretDirectory);
            if (profiles.Count == 0)
            {
                MessageBox.Show("В выбранной папке не найдены профили General из пакета Flowseal.", "Нет стратегий",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (engineManager.RefreshStatus())
                await engineManager.StopAsync();

            string? bestFile = null;
            int bestScore = 0;
            IReadOnlyList<ServiceCheckResult>? bestChecks = null;
            bool perfectMatch = false;

            AddLog($"Начат автоматический подбор. Найдено профилей: {profiles.Count}.");
            for (int i = 0; i < profiles.Count; i++)
            {
                string fileName = profiles[i];
                string displayName = StrategyManager.DisplayName(fileName);
                TestProgressText.Text = $"Проверка {i + 1} из {profiles.Count}: {displayName}";
                TestProgressBar.Value = (double)i / profiles.Count * 100;
                ModuleStatus.Text = $"Тестируем {displayName}...";
                StatusText.Text = "Идёт подбор...";
                AddLog($"Тест профиля {fileName}");

                bool started;
                try
                {
                    started = await engineManager.StartAsync(settings.ZapretDirectory, fileName);
                }
                catch (Exception ex)
                {
                    AddLog($"Не удалось запустить {fileName}: {ex.Message}");
                    TestResultsList.Items.Insert(0, $"✕  {displayName} — ошибка запуска: {ex.Message}");
                    continue;
                }

                if (!started)
                {
                    string logHint = string.IsNullOrWhiteSpace(engineManager.LastLogPath)
                        ? ""
                        : $" · журнал: {engineManager.LastLogPath}";
                    TestResultsList.Items.Insert(0, $"✕  {displayName} — движок не запустился{logHint}");
                    continue;
                }

                // Даём WinDivert и профилю немного времени примениться к новым соединениям.
                await Task.Delay(1600);
                IReadOnlyList<ServiceCheckResult> checks = await diagnostics.CheckImportantServicesAsync();
                int score = checks.Count(x => x.IsReachable);
                string serviceSummary = string.Join("   ·   ", checks.Select(x => $"{x.Service} {(x.IsReachable ? "✓" : "✕")}"));
                string row = $"{(score == checks.Count ? "✓" : score > 0 ? "◐" : "✕")}  {displayName}   ·   {serviceSummary}   ·   {score}/{checks.Count}";
                TestResultsList.Items.Insert(0, row);
                TestProgressBar.Value = (double)(i + 1) / profiles.Count * 100;
                AddLog($"Результат {fileName}: {serviceSummary}; {score}/{checks.Count}.");

                if (score > bestScore)
                {
                    bestScore = score;
                    bestFile = fileName;
                    bestChecks = checks;
                }

                if (score == checks.Count)
                {
                    bestFile = fileName;
                    bestScore = score;
                    bestChecks = checks;
                    perfectMatch = true;
                    break;
                }

                await engineManager.StopAsync();
            }

            if (bestFile is null || bestScore == 0)
            {
                if (engineManager.RefreshStatus())
                    await engineManager.StopAsync();
                TestProgressText.Text = "Подходящий профиль не найден";
                ModuleStatus.Text = "Ни один профиль не открыл тестовые HTTPS-узлы. Проверьте WinDivert, антивирус, сеть и попробуйте вручную.";
                YoutubeStatus.Text = "Не удалось подтвердить доступность.";
                DiscordStatus.Text = "Не удалось подтвердить доступность.";
                TelegramStatus.Text = "Не удалось подтвердить доступность.";
                AddLog("Автоподбор завершён: ни один профиль не прошёл проверку.");
                return;
            }

            if (!engineManager.RefreshStatus() || !string.Equals(engineManager.ActiveStrategyFile, bestFile, StringComparison.OrdinalIgnoreCase))
            {
                if (engineManager.RefreshStatus())
                    await engineManager.StopAsync();
                bool restored = await engineManager.StartAsync(settings.ZapretDirectory, bestFile);
                if (!restored)
                    throw new InvalidOperationException("Найденный профиль прошёл тест, но не удалось повторно его запустить.");
            }

            SelectProfile(bestFile);
            settings.ZapretStrategyFile = bestFile;
            SaveSettings();
            UpdateServiceCards(bestChecks!);
            TestProgressBar.Value = 100;
            TestProgressText.Text = perfectMatch
                ? "Найден профиль с доступом ко всем проверяемым сервисам"
                : $"Лучший результат: {bestScore}/{bestChecks!.Count} · профиль оставлен включённым";
            ModuleStatus.Text = $"Выбран {StrategyManager.DisplayName(bestFile)}. Профиль оставлен работать в фоне.";
            StatusText.Text = "Стратегия подобрана";
            AddLog($"Автоподбор завершён. Выбран {bestFile}, результат {bestScore}/{bestChecks!.Count}.");
        }
        catch (Exception ex)
        {
            AddLog("Ошибка автоподбора: " + ex.Message);
            TestProgressText.Text = "Ошибка проверки";
            ModuleStatus.Text = ex.Message;
            MessageBox.Show(ex.Message, "Ошибка автоподбора", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            SetActionButtonsEnabled(true);
            StrategyBox.IsEnabled = true;
            UpdateEngineUi();
        }
    }

    private void SelectProfile(string fileName)
    {
        isLoadingSettings = true;
        SelectComboBoxProfile(StrategyBox, fileName);
        SelectComboBoxProfile(HomeStrategyBox, fileName);
        isLoadingSettings = false;

        CurrentStrategy.Text = StrategyManager.DisplayName(fileName);
        ActiveProfileFileText.Text = Path.GetFileNameWithoutExtension(fileName);
        StrategyDescription.Text = "Автоподбор выбрал этот профиль по результатам проверки YouTube, Discord и Telegram Web.";
    }

    private static void SelectComboBoxProfile(ComboBox box, string fileName)
    {
        ComboBoxItem? match = box.Items.OfType<ComboBoxItem>()
            .FirstOrDefault(item => string.Equals(item.Tag as string, fileName, StringComparison.OrdinalIgnoreCase));
        if (match is not null)
            box.SelectedItem = match;
    }

    private async Task CheckCurrentServicesAsync()
    {
        IReadOnlyList<ServiceCheckResult> checks = await diagnostics.CheckImportantServicesAsync();
        UpdateServiceCards(checks);
        foreach (ServiceCheckResult check in checks)
            AddLog($"Проверка {check.Service}: {check.Details}");
    }

    private void UpdateServiceCards(IReadOnlyList<ServiceCheckResult> checks)
    {
        ServiceCheckResult? youtube = checks.FirstOrDefault(x => x.Service == "YouTube");
        ServiceCheckResult? discord = checks.FirstOrDefault(x => x.Service == "Discord");
        ServiceCheckResult? telegram = checks.FirstOrDefault(x => x.Service == "Telegram");
        if (youtube is not null)
        {
            YoutubeStatus.Text = youtube.Details;
            YoutubeStatus.Foreground = youtube.IsReachable ? new SolidColorBrush(Color.FromRgb(80, 211, 163)) : new SolidColorBrush(Color.FromRgb(239, 132, 143));
        }
        if (discord is not null)
        {
            DiscordStatus.Text = discord.Details;
            DiscordStatus.Foreground = discord.IsReachable ? new SolidColorBrush(Color.FromRgb(80, 211, 163)) : new SolidColorBrush(Color.FromRgb(239, 132, 143));
        }
        if (telegram is not null)
        {
            TelegramStatus.Text = telegram.Details;
            TelegramStatus.Foreground = telegram.IsReachable ? new SolidColorBrush(Color.FromRgb(80, 211, 163)) : new SolidColorBrush(Color.FromRgb(239, 132, 143));
        }
    }

    private void SelectZapret_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog
        {
            Title = "Выберите корневую папку распакованного пакета Flowseal",
            Multiselect = false
        };

        if (dialog.ShowDialog(this) != true)
            return;

        string folder = dialog.FolderName;
        try
        {
            folder = EngineManager.ResolveBundleRoot(folder);
            IReadOnlyList<string> profiles = StrategyManager.FindProfiles(folder);
            if (profiles.Count == 0)
                throw new FileNotFoundException("В выбранной папке не найдены профили General из пакета Flowseal.");
            string script = Path.Combine(folder, profiles[0]);
            string executable = Path.Combine(folder, "bin", "winws.exe");
            EngineManager.ValidateBundle(folder, script, executable);

            if (engineManager.RefreshStatus() || engineManager.IsZapretServiceRunning || engineManager.IsAnyWinwsProcessRunning)
            {
                MessageBox.Show("Перед сменой папки сначала остановите текущий профиль или службу Flowseal.", "Движок работает",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            settings.ZapretDirectory = folder;
            settings.ZapretStrategyFile = profiles.Contains("general.bat", StringComparer.OrdinalIgnoreCase)
                ? "general.bat"
                : profiles[0];
            engineManager.Configure(folder);
            LoadStrategies(settings.ZapretStrategyFile);
            SaveSettings();
            AddLog("Выбран пакет Flowseal: " + folder);
            if (folder.Any(ch => ch > 127) || folder.Contains(' '))
                AddLog("Совет: для совместимости лучше распаковать Flowseal в путь без пробелов и кириллицы, например C:\\zapret-flowseal.");
            UpdateEngineUi();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Папка Flowseal не подходит", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void DiagnosePackage_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string report = EngineManager.BuildDiagnostics(settings.ZapretDirectory, settings.ZapretStrategyFile);
            AddLog("Выполнена проверка пакета Flowseal.");
            foreach (string line in report.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                AddLog(line);

            MessageBox.Show(report, "Диагностика WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            AddLog("Ошибка диагностики: " + ex.Message);
            MessageBox.Show(ex.Message, "Диагностика WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void StrategyBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        => HandleStrategySelection(StrategyBox);

    private void HomeStrategyBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        => HandleStrategySelection(HomeStrategyBox);

    private void HandleStrategySelection(ComboBox source)
    {
        if (isLoadingSettings || source.SelectedItem is not ComboBoxItem item || item.Tag is not string fileName)
            return;

        if (engineManager.RefreshStatus() || engineManager.IsZapretServiceRunning || engineManager.IsAnyWinwsProcessRunning)
        {
            string activeFile = engineManager.ActiveStrategyFile ?? settings.ZapretStrategyFile;
            SelectProfile(activeFile);
            StrategyDescription.Text = "Чтобы сменить General, сначала остановите текущий профиль.";
            AddLog("Смена General недоступна, пока сетевой движок работает. Сначала нажмите «Остановить Zapret».");
            return;
        }

        isLoadingSettings = true;
        SelectComboBoxProfile(StrategyBox, fileName);
        SelectComboBoxProfile(HomeStrategyBox, fileName);
        isLoadingSettings = false;

        settings.ZapretStrategyFile = fileName;
        telemetry.CurrentStrategy = fileName;
        CurrentStrategy.Text = StrategyManager.DisplayName(fileName);
        ActiveProfileFileText.Text = Path.GetFileNameWithoutExtension(fileName);
        StrategyDescription.Text = "Выбран профиль Flowseal: " + StrategyManager.DisplayName(fileName) + ". Нажмите «Включить Zapret», чтобы запустить winws.exe напрямую.";
        SaveSettings();
        AddLog("Выбран профиль: " + fileName);
        UpdateEngineUi();
    }

    private void TelemetryChanged(object sender, RoutedEventArgs e)
    {
        if (isLoadingSettings)
            return;

        bool enabled = TelemetryBox.IsChecked == true;
        settings.TelemetryEnabled = enabled;
        SaveSettings();
        if (enabled)
        {
            telemetry.Start(settings.ZapretStrategyFile);
            AddLog("Анонимная статистика включена.");
        }
        else
        {
            telemetry.Stop();
            AddLog("Анонимная статистика выключена.");
        }
    }

    private void SettingChanged(object sender, RoutedEventArgs e)
    {
        if (isLoadingSettings)
            return;

        bool enabled = AutoStartBox.IsChecked == true;
        try
        {
            startupManager.SetEnabled(enabled);
            settings.AutoStart = enabled;
            SaveSettings();
            AddLog(enabled ? "Автозапуск WhyNoDPI включён." : "Автозапуск WhyNoDPI выключен.");
        }
        catch (Exception ex)
        {
            isLoadingSettings = true;
            AutoStartBox.IsChecked = settings.AutoStart;
            isLoadingSettings = false;
            AddLog("Не удалось изменить автозапуск: " + ex.Message);
            MessageBox.Show(ex.Message, "Настройка автозапуска", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void SaveSettings()
    {
        try { settings.Save(); }
        catch (Exception ex) { AddLog("Не удалось сохранить настройки: " + ex.Message); }
    }

    private void AddLog(string message)
    {
        if (LogList is null)
            return;
        LogList.Items.Insert(0, $"[{DateTime.Now:HH:mm:ss}]  {message}");
        while (LogList.Items.Count > 500)
            LogList.Items.RemoveAt(LogList.Items.Count - 1);
    }

    private void ClearLog_Click(object sender, RoutedEventArgs e)
    {
        LogList.Items.Clear();
        AddLog("Журнал очищен.");
    }

    private void OpenLogs_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            string logDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WhyNoDPI", "logs");
            Directory.CreateDirectory(logDirectory);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{logDirectory}\"") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            AddLog("Не удалось открыть папку логов: " + ex.Message);
            MessageBox.Show(ex.Message, "WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void OpenFlowseal_Click(object sender, RoutedEventArgs e) => OpenUrl("https://github.com/Flowseal/zapret-discord-youtube");
    private void OpenFlowsealRelease_Click(object sender, RoutedEventArgs e) => OpenUrl("https://github.com/Flowseal/zapret-discord-youtube/releases/latest");
    private async void OpenYoutube_Click(object sender, RoutedEventArgs e) => await OpenServiceAsync("https://www.youtube.com", "YouTube");
    private async void OpenDiscord_Click(object sender, RoutedEventArgs e) => await OpenDiscordDesktopAsync();
    private async void OpenTelegram_Click(object sender, RoutedEventArgs e) => await OpenServiceAsync("https://web.telegram.org", "Telegram Web");

    private void OpenTelegramProxyChannel_Click(object sender, RoutedEventArgs e)
    {
        OpenUrl("https://t.me/mtp4tg");
        TelegramProxyStatusText.Text = "Открыт канал @mtp4tg. Выбери отдельный прокси с отметкой Online и нажми Connect в Telegram.";
        AddLog("Открыт канал MTProxy for Telegram (@mtp4tg).");
    }

    private void ImportTelegramProxyLink_Click(object sender, RoutedEventArgs e)
    {
        if (!TelegramProxyLinkHelper.TryParse(TelegramProxyLinkBox.Text, out string server, out int port, out string secret, out string error))
        {
            TelegramProxyStatusText.Text = error;
            TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
            MessageBox.Show(error, "Ссылка на MTProto-прокси", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        TelegramProxyServerBox.Text = server;
        TelegramProxyPortBox.Text = port.ToString();
        TelegramProxySecretBox.Password = secret;
        TelegramProxyStatusText.Text = $"Параметры импортированы: {server}:{port}. Нажми «Подключить в Telegram» для подтверждения в клиенте.";
        TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(80, 211, 163));
        AddLog($"Импортированы параметры MTProto-прокси для {server}:{port}; секрет не записывается в журнал.");
    }

    private void ConnectTelegramProxy_Click(object sender, RoutedEventArgs e)
    {
        string server = TelegramProxyServerBox.Text.Trim();
        string portText = TelegramProxyPortBox.Text.Trim();
        string secret = TelegramProxySecretBox.Password.Trim();

        if (!int.TryParse(portText, out int port))
        {
            TelegramProxyStatusText.Text = "Порт должен быть числом от 1 до 65535.";
            TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
            MessageBox.Show(TelegramProxyStatusText.Text, "Некорректный порт", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!TelegramProxyLinkHelper.TryBuild(server, port, secret, out string telegramUri, out string error))
        {
            TelegramProxyStatusText.Text = error;
            TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
            MessageBox.Show(TelegramProxyStatusText.Text, "Некорректные параметры прокси", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo(telegramUri) { UseShellExecute = true });
            TelegramProxyStatusText.Text = "Ссылка передана Telegram. Подтверди подключение в открывшемся окне Telegram.";
            TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(80, 211, 163));
            AddLog($"Открыта ссылка добавления MTProto-прокси {server}:{port}; secret не журналируется.");
        }
        catch (Exception ex)
        {
            // Browser deep-link is a fallback when the Telegram tg:// handler is not registered.
            string webLink = TelegramProxyLinkHelper.ToWebLink(server, port, secret);
            try
            {
                Process.Start(new ProcessStartInfo(webLink) { UseShellExecute = true });
                TelegramProxyStatusText.Text = "Не найден обработчик tg://. Открыта ссылка t.me/proxy в браузере — выбери «Open in Telegram».";
                TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 180, 92));
                AddLog("Ссылка tg://proxy не открылась; использован HTTPS fallback t.me/proxy.");
            }
            catch (Exception fallbackEx)
            {
                TelegramProxyStatusText.Text = "Не удалось открыть Telegram: " + fallbackEx.Message;
                TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
                AddLog("Не удалось открыть ссылку MTProto: " + ex.Message + " / " + fallbackEx.Message);
            }
        }
    }

    private void ClearTelegramProxy_Click(object sender, RoutedEventArgs e)
    {
        TelegramProxyLinkBox.Clear();
        TelegramProxyServerBox.Clear();
        TelegramProxyPortBox.Clear();
        TelegramProxySecretBox.Clear();
        TelegramProxyStatusText.Text = "Поля очищены. Секрет прокси не сохраняется в настройках WhyNoDPI.";
        TelegramProxyStatusText.Foreground = new SolidColorBrush(Color.FromRgb(145, 160, 184));
    }

    private void OpenWindowsVpnSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("ms-settings:network-vpn") { UseShellExecute = true });
            AddLog("Открыты системные настройки VPN Windows.");
        }
        catch (Exception ex)
        {
            AddLog("Не удалось открыть настройки VPN Windows: " + ex.Message);
            MessageBox.Show(ex.Message, "Настройки VPN", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void RefreshVpnStatus_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            NetworkInterface[] candidates = NetworkInterface.GetAllNetworkInterfaces()
                .Where(adapter => adapter.OperationalStatus == OperationalStatus.Up &&
                    (adapter.NetworkInterfaceType is NetworkInterfaceType.Tunnel or NetworkInterfaceType.Ppp ||
                     adapter.Name.Contains("WireGuard", StringComparison.OrdinalIgnoreCase) ||
                     adapter.Name.Contains("Wintun", StringComparison.OrdinalIgnoreCase) ||
                     adapter.Name.Contains("TAP", StringComparison.OrdinalIgnoreCase) ||
                     adapter.Description.Contains("WireGuard", StringComparison.OrdinalIgnoreCase) ||
                     adapter.Description.Contains("OpenVPN", StringComparison.OrdinalIgnoreCase) ||
                     adapter.Description.Contains("VPN", StringComparison.OrdinalIgnoreCase)))
                .ToArray();

            if (candidates.Length == 0)
            {
                VpnStatusText.Text = "Активный VPN-подобный интерфейс не обнаружен. Это не исключает VPN-функции внутри отдельных приложений.";
                VpnStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 180, 92));
            }
            else
            {
                string names = string.Join(", ", candidates.Select(adapter => adapter.Name).Distinct().Take(5));
                VpnStatusText.Text = "Обнаружены активные туннельные/PPP/VPN-интерфейсы: " + names + ". Это признак адаптера, а не гарантия, что через него направлен весь трафик.";
                VpnStatusText.Foreground = new SolidColorBrush(Color.FromRgb(80, 211, 163));
            }
            AddLog("Проверены сетевые интерфейсы Windows для поиска VPN/туннелей.");
        }
        catch (Exception ex)
        {
            VpnStatusText.Text = "Не удалось проверить сетевые интерфейсы: " + ex.Message;
            VpnStatusText.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
        }
    }

    private async Task OpenDiscordDesktopAsync()
    {
        try
        {
            // При наличии уже работающего Flowseal/Zapret не запускаем второй winws.
            bool bypassActive = engineManager.RefreshStatus() ||
                                engineManager.IsZapretServiceRunning ||
                                engineManager.IsAnyWinwsProcessRunning;

            if (!bypassActive)
            {
                if (string.IsNullOrWhiteSpace(settings.ZapretDirectory) || !Directory.Exists(settings.ZapretDirectory))
                {
                    DiscordStatus.Text = "Сначала выберите пакет Flowseal";
                    DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(239, 180, 92));
                    MessageBox.Show(
                        "Сначала выберите корневую папку распакованного пакета Flowseal в разделе «Настройки», затем выберите нужный General.",
                        "Пакет Flowseal не выбран", MessageBoxButton.OK, MessageBoxImage.Information);
                    ShowPage(SettingsPage, "Настройки");
                    return;
                }

                DiscordStatus.Text = "Запускается выбранный General...";
                DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(239, 180, 92));
                bool started = await engineManager.StartAsync(settings.ZapretDirectory, settings.ZapretStrategyFile);
                if (!started)
                {
                    DiscordStatus.Text = "Zapret не запущен — Discord не открыт";
                    DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
                    AddLog("Discord не запущен: выбранный профиль не стартовал. Последний журнал: " + (engineManager.LastLogPath ?? "не создан"));
                    MessageBox.Show(
                        (engineManager.LastFailureMessage ?? "Не удалось запустить выбранный профиль Zapret.") +
                        "\n\nDiscord не будет открыт, чтобы не создавать впечатление, что обход уже работает." +
                        (string.IsNullOrWhiteSpace(engineManager.LastLogPath) ? string.Empty : "\n\nЖурнал: " + engineManager.LastLogPath),
                        "Не удалось запустить Zapret", MessageBoxButton.OK, MessageBoxImage.Warning);
                    UpdateEngineUi();
                    return;
                }

                await Task.Delay(1000);
                bypassActive = engineManager.RefreshStatus();
                if (!bypassActive)
                {
                    DiscordStatus.Text = "Движок остановился при запуске";
                    DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
                    AddLog("winws.exe завершился до запуска Discord.");
                    UpdateEngineUi();
                    return;
                }
            }
            else
            {
                AddLog(engineManager.IsZapretServiceRunning
                    ? "Для Discord используется уже работающая служба Flowseal; второй движок не запускается."
                    : "Для Discord используется уже работающий winws.exe; повторный профиль не запускается.");
            }

            (bool success, string details) = await TryLaunchDiscordDesktopAsync();
            if (success)
            {
                DiscordStatus.Text = "Discord Desktop открыт";
                DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(80, 211, 163));
                AddLog("Discord Desktop запущен обычным пользовательским процессом: " + details);
                UpdateEngineUi();
                return;
            }

            DiscordStatus.Text = "Не удалось запустить Discord Desktop";
            DiscordStatus.Foreground = new SolidColorBrush(Color.FromRgb(239, 132, 143));
            AddLog("Discord Desktop не найден или не запустился. Проверенные варианты: " + details);
            MessageBoxResult choice = MessageBox.Show(
                "Не удалось запустить установленное приложение Discord.\n\nОткрыть официальную страницу загрузки Discord?",
                "Discord не запущен", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (choice == MessageBoxResult.Yes)
                OpenUrl("https://discord.com/download");
        }
        catch (Exception ex)
        {
            AddLog("Не удалось запустить Discord Desktop: " + ex.Message);
            MessageBox.Show(ex.Message, "Ошибка запуска Discord", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static async Task<(bool Success, string Details)> TryLaunchDiscordDesktopAsync()
    {
        string[] processNames = { "Discord", "DiscordPTB", "DiscordCanary" };
        if (IsDiscordProcessRunning(processNames))
            return (true, "Discord уже запущен");

        string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string[] installFolders = { "Discord", "DiscordPTB", "DiscordCanary" };
        var attempted = new List<string>();

        foreach (string folderName in installFolders)
        {
            string installRoot = Path.Combine(localAppData, folderName);
            string processExe = folderName switch
            {
                "DiscordPTB" => "DiscordPTB.exe",
                "DiscordCanary" => "DiscordCanary.exe",
                _ => "Discord.exe"
            };
            string processName = Path.GetFileNameWithoutExtension(processExe);
            string updater = Path.Combine(installRoot, "Update.exe");

            if (File.Exists(updater))
            {
                attempted.Add(updater);
                if (TryStartUnelevated(updater, $"--processStart {processExe}", installRoot) &&
                    await WaitForDiscordProcessAsync(processName, TimeSpan.FromSeconds(10)))
                    return (true, updater + " → " + processExe);
            }

            if (Directory.Exists(installRoot))
            {
                string[] appDirectories;
                try
                {
                    appDirectories = Directory.GetDirectories(installRoot, "app-*", SearchOption.TopDirectoryOnly)
                        .OrderByDescending(path => path, StringComparer.OrdinalIgnoreCase)
                        .ToArray();
                }
                catch
                {
                    appDirectories = Array.Empty<string>();
                }

                foreach (string appDirectory in appDirectories)
                {
                    string executable = Path.Combine(appDirectory, processExe);
                    attempted.Add(executable);
                    if (TryStartUnelevated(executable, string.Empty, appDirectory) &&
                        await WaitForDiscordProcessAsync(processName, TimeSpan.FromSeconds(8)))
                        return (true, executable);
                }
            }
        }

        string[] fixedPaths =
        {
            Path.Combine(localAppData, "Programs", "Discord", "Discord.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Discord", "Discord.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Discord", "Discord.exe")
        };
        foreach (string executable in fixedPaths)
        {
            attempted.Add(executable);
            if (TryStartUnelevated(executable, string.Empty, Path.GetDirectoryName(executable) ?? localAppData) &&
                await WaitForDiscordProcessAsync("Discord", TimeSpan.FromSeconds(8)))
                return (true, executable);
        }

        // URI-протокол полезен для Microsoft Store и других установок Discord.
        attempted.Add("discord:// protocol");
        if (TryStartUnelevated("discord://", string.Empty, localAppData) &&
            await WaitForDiscordProcessAsync("Discord", TimeSpan.FromSeconds(8)))
            return (true, "discord:// protocol");

        return (false, string.Join("; ", attempted));
    }

    private static bool TryStartUnelevated(string target, string arguments, string workingDirectory)
    {
        try
        {
            // WhyNoDPI запрашивает UAC для WinDivert. Передача запуска через
            // Explorer позволяет Discord открываться как обычное desktop-приложение,
            // а не наследовать повышенный токен WhyNoDPI.
            string explorer = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe");
            string command = "\"" + target + "\"";
            if (!string.IsNullOrWhiteSpace(arguments))
                command += " " + arguments;

            Process.Start(new ProcessStartInfo
            {
                FileName = explorer,
                Arguments = command,
                WorkingDirectory = workingDirectory,
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Hidden
            });
            return true;
        }
        catch
        {
            // Резервный вариант для систем, где Explorer не принимает команду запуска.
            try
            {
                var info = new ProcessStartInfo
                {
                    FileName = target,
                    WorkingDirectory = workingDirectory,
                    UseShellExecute = true
                };
                if (!string.IsNullOrWhiteSpace(arguments))
                    info.Arguments = arguments;
                Process.Start(info);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    private static async Task<bool> WaitForDiscordProcessAsync(string processName, TimeSpan timeout)
    {
        DateTime deadline = DateTime.UtcNow + timeout;
        while (DateTime.UtcNow < deadline)
        {
            if (IsDiscordProcessRunning(new[] { processName }))
                return true;
            await Task.Delay(250);
        }
        return IsDiscordProcessRunning(new[] { processName });
    }

    private static bool IsDiscordProcessRunning(IEnumerable<string> processNames)
    {
        foreach (string processName in processNames)
        {
            Process[] processes;
            try { processes = Process.GetProcessesByName(processName); }
            catch { continue; }

            bool found = processes.Length > 0;
            foreach (Process process in processes)
                process.Dispose();
            if (found)
                return true;
        }
        return false;
    }

    private async Task OpenServiceAsync(string url, string serviceName)
    {
        try
        {
            bool bypassActive = engineManager.RefreshStatus() ||
                                engineManager.IsZapretServiceRunning ||
                                engineManager.IsAnyWinwsProcessRunning;
            if (!bypassActive)
            {
                if (string.IsNullOrWhiteSpace(settings.ZapretDirectory))
                {
                    MessageBox.Show("Сначала выберите пакет Flowseal в настройках.", "Пакет не выбран",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    ShowPage(SettingsPage, "Настройки");
                    return;
                }

                bool started = await engineManager.StartAsync(settings.ZapretDirectory, settings.ZapretStrategyFile);
                if (!started)
                {
                    MessageBox.Show("Не удалось запустить выбранный профиль. Откройте журнал WhyNoDPI для подробностей.", "Zapret не запущен",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                await Task.Delay(700);
            }

            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            AddLog($"Открыт {serviceName} через работающий Zapret.");
            UpdateEngineUi();
        }
        catch (Exception ex)
        {
            AddLog($"Не удалось открыть {serviceName}: {ex.Message}");
            MessageBox.Show(ex.Message, "Ошибка открытия сайта", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void OpenUrl(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
        catch (Exception ex)
        {
            AddLog("Не удалось открыть ссылку: " + ex.Message);
            MessageBox.Show(ex.Message, "WhyNoDPI", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    protected override void OnClosed(EventArgs e)
    {
        telemetry.Stop();
        base.OnClosed(e);
    }

    private async void Window_Closing(object? sender, CancelEventArgs e)
    {
        if (allowClose || engineManager.IsZapretServiceRunning || !engineManager.RefreshStatus())
            return;

        // Не выключаем обход неожиданно: пользователь мог закрыть только окно,
        // рассчитывая продолжить пользоваться Discord/YouTube.
        e.Cancel = true;
        MessageBoxResult choice = MessageBox.Show(
            "Сетевой движок WhyNoDPI сейчас работает. Что сделать перед закрытием?\n\n" +
            "Да — остановить Zapret и закрыть приложение.\n" +
            "Нет — закрыть окно, оставив Zapret работать в фоне.\n" +
            "Отмена — вернуться в приложение.",
            "WhyNoDPI всё ещё работает", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);

        if (choice == MessageBoxResult.Cancel)
            return;

        if (choice == MessageBoxResult.No)
        {
            AddLog("Окно закрывается; сетевой движок оставлен работать в фоне.");
            allowClose = true;
            Close();
            return;
        }

        SetActionButtonsEnabled(false);
        try
        {
            AddLog("Закрытие приложения: останавливаем сетевой движок...");
            await engineManager.StopAsync();
        }
        catch (Exception ex)
        {
            AddLog("Ошибка при остановке движка: " + ex.Message);
        }
        allowClose = true;
        Close();
    }
}
