using System.Windows;

namespace NoDPI;

public partial class App : Application
{
}
