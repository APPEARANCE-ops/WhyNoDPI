using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace NoDPI.Core;

/// <summary>
/// Anonymous telemetry for the admin panel: reports that this installation is
/// running so the administrator can see how many users are online.
///
/// Security and privacy rules:
///  - Sends ONLY an anonymous random GUID, app version, OS string and the
///    selected strategy file name. No personal data, no passwords, no proxy
///    secrets, no file paths, no IP addresses of the user.
///  - The server stores the GUID only as a salted SHA-256 hash (pepper lives
///    on the server), so telemetry cannot be linked back to a person.
///  - Fire-and-forget: never blocks the UI, never throws, silently ignores
///    network failures; works fully offline.
///  - Can be disabled in settings (TelemetryEnabled) or completely removed
///    by deleting this file and the three call sites in MainWindow.
/// </summary>
public sealed class TelemetryClient : IDisposable
{
    /// <summary>
    /// Base URL of your admin-panel server. CHANGE THIS after deploying the
    /// panel (for example: "https://panel.example.com"). Trailing slash is
    /// optional. It can also be overridden with the WHYNODPI_TELEMETRY_URL
    /// environment variable (handy for testing without rebuilding).
    /// </summary>
    public const string DefaultServerUrl = "https://your-panel-domain.example";

    private const int HeartbeatIntervalSeconds = 60;
    private static readonly TimeSpan RequestTimeout = TimeSpan.FromSeconds(5);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
    };

    private static readonly HttpClient Http = new()
    {
        Timeout = RequestTimeout,
    };

    private readonly string folderPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "WhyNoDPI");
    private string StorePath => Path.Combine(folderPath, "telemetry.json");

    private Timer? timer;
    private string? installId;
    private string serverUrl = string.Empty;
    private string? currentStrategy;
    private int running;

    /// <summary>Latest selected strategy file; picked up by the next heartbeat.</summary>
    public string? CurrentStrategy
    {
        get => currentStrategy;
        set => currentStrategy = value;
    }

    private static string ResolveServerUrl()
    {
        string? env = Environment.GetEnvironmentVariable("WHYNODPI_TELEMETRY_URL");
        if (!string.IsNullOrWhiteSpace(env))
            return env.TrimEnd('/');
        return DefaultServerUrl.TrimEnd('/');
    }

    public void Start(string? strategyFile)
    {
        if (Interlocked.Exchange(ref running, 1) == 1)
            return; // already running

        serverUrl = ResolveServerUrl();
        bool usingPlaceholder = !string.IsNullOrWhiteSpace(Environment.GetEnvironmentVariable("WHYNODPI_TELEMETRY_URL"))
            ? false
            : DefaultServerUrl.Contains("your-panel-domain");
        if (serverUrl.Length == 0 || usingPlaceholder)
        {
            // Panel URL is not configured yet: telemetry stays off instead of
            // hammering a placeholder address.
            Interlocked.Exchange(ref running, 0);
            return;
        }

        installId = LoadOrCreateInstallId();
        if (installId is null)
        {
            Interlocked.Exchange(ref running, 0);
            return;
        }

        currentStrategy = strategyFile;
        _ = SendAsync("start", strategyFile);

        timer = new Timer(
            _ => _ = SendAsync("heartbeat", currentStrategy),
            null,
            TimeSpan.FromSeconds(HeartbeatIntervalSeconds),
            TimeSpan.FromSeconds(HeartbeatIntervalSeconds));
    }

    public void Stop()
    {
        if (Interlocked.Exchange(ref running, 0) == 0)
            return;

        timer?.Dispose();
        timer = null;

        // Best-effort goodbye so the admin panel marks us offline immediately.
        _ = SendAsync("stop", null);
    }

    private string? LoadOrCreateInstallId()
    {
        try
        {
            Directory.CreateDirectory(folderPath);
            if (File.Exists(StorePath))
            {
                try
                {
                    using JsonDocument doc = JsonDocument.Parse(File.ReadAllText(StorePath));
                    if (doc.RootElement.TryGetProperty("installId", out JsonElement id))
                    {
                        string? value = id.GetString();
                        if (!string.IsNullOrWhiteSpace(value) && value.Length <= 64)
                            return value;
                    }
                }
                catch (JsonException)
                {
                    // Corrupted store: regenerate below.
                }
            }

            string fresh = Guid.NewGuid().ToString("D");
            string json = JsonSerializer.Serialize(new TelemetryStore { InstallId = fresh }, JsonOptions);
            string tempPath = StorePath + ".tmp";
            File.WriteAllText(tempPath, json);
            File.Move(tempPath, StorePath, overwrite: true);
            return fresh;
        }
        catch
        {
            return null; // telemetry must never break the app
        }
    }

    private async Task SendAsync(string @event, string? strategyFile)
    {
        if (installId is null || serverUrl.Length == 0)
            return;

        try
        {
            var payload = new TelemetryPayload
            {
                InstallId = installId,
                Version = GetAppVersion(),
                Os = Environment.OSVersion.VersionString,
                Strategy = string.IsNullOrWhiteSpace(strategyFile) ? "-" : strategyFile,
                Event = @event,
            };

            using StringContent content = new(
                JsonSerializer.Serialize(payload, JsonOptions),
                Encoding.UTF8,
                "application/json");

            using HttpResponseMessage response = await Http
                .PostAsync(serverUrl + "/api/heartbeat", content)
                .ConfigureAwait(false);
            _ = response.StatusCode; // outcome is intentionally ignored
        }
        catch
        {
            // Offline, timeout, DNS failure — telemetry is never important
            // enough to surface an error to the user.
        }
    }

    private static string GetAppVersion()
    {
        try
        {
            Version? v = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            return v is null ? "unknown" : v.ToString(3);
        }
        catch
        {
            return "unknown";
        }
    }

    public void Dispose()
    {
        Stop();
    }

    private sealed class TelemetryStore
    {
        public string InstallId { get; set; } = string.Empty;
    }

    private sealed class TelemetryPayload
    {
        public string InstallId { get; set; } = string.Empty;
        public string Version { get; set; } = "unknown";
        public string Os { get; set; } = "windows";
        public string Strategy { get; set; } = "-";
        public string Event { get; set; } = "heartbeat";
    }
}
