using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace NoDPI.Core
{
    public sealed record FlowsealUpdateResult(
        string Version,
        string Status,
        string ArchivePath);

    public sealed class FlowsealUpdateManager
    {
        private const string ReleaseApiUrl =
            "https://api.github.com/repos/Flowseal/zapret-discord-youtube/releases/latest";
        private const string ReleasePageUrl =
            "https://github.com/Flowseal/zapret-discord-youtube/releases";
        private const long MaximumArchiveSize = 100 * 1024 * 1024;
        private static readonly HttpClient HttpClient = CreateHttpClient();

        private readonly string downloadDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "NoDPI",
            "ExternalUpdates",
            "Flowseal");

        public async Task<FlowsealUpdateResult> CheckAndDownloadLatestAsync(
            CancellationToken cancellationToken = default)
        {
            using HttpResponseMessage releaseResponse = await HttpClient.GetAsync(
                ReleaseApiUrl,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken);
            releaseResponse.EnsureSuccessStatusCode();

            await using Stream releaseStream = await releaseResponse.Content.ReadAsStreamAsync(cancellationToken);
            using JsonDocument releaseDocument = await JsonDocument.ParseAsync(
                releaseStream,
                cancellationToken: cancellationToken);

            JsonElement release = releaseDocument.RootElement;
            string version = GetRequiredString(release, "tag_name");
            JsonElement asset = FindZipAsset(release);
            string assetName = GetRequiredString(asset, "name");
            string downloadUrl = GetRequiredString(asset, "browser_download_url");
            string digest = GetRequiredString(asset, "digest");
            long assetSize = asset.GetProperty("size").GetInt64();
            long assetId = asset.GetProperty("id").GetInt64();

            if (assetSize <= 0 || assetSize > MaximumArchiveSize)
                throw new InvalidDataException("Размер официального архива не прошёл проверку.");

            if (!Uri.TryCreate(downloadUrl, UriKind.Absolute, out Uri? assetUri) ||
                assetUri.Scheme != Uri.UriSchemeHttps ||
                !string.Equals(assetUri.Host, "github.com", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("Ссылка на архив не ведёт на официальный домен GitHub.");
            }

            string expectedHash = ParseSha256Digest(digest);
            string safeName = Path.GetFileName(assetName);
            if (!safeName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Официальный релиз не содержит ожидаемый ZIP-архив.");

            Directory.CreateDirectory(downloadDirectory);
            string archivePath = Path.Combine(downloadDirectory, $"Flowseal-{assetId}-{safeName}");

            if (File.Exists(archivePath))
            {
                string cachedHash = await ComputeFileSha256Async(archivePath, cancellationToken);
                if (string.Equals(cachedHash, expectedHash, StringComparison.OrdinalIgnoreCase))
                {
                    return new FlowsealUpdateResult(
                        version,
                        "Последний официальный архив уже скачан и проверен.",
                        archivePath);
                }

                File.Delete(archivePath);
            }

            string temporaryPath = archivePath + ".download";
            try
            {
                await DownloadAndVerifyAsync(
                    assetUri,
                    temporaryPath,
                    assetSize,
                    expectedHash,
                    cancellationToken);
                File.Move(temporaryPath, archivePath, true);
            }
            finally
            {
                if (File.Exists(temporaryPath))
                    File.Delete(temporaryPath);
            }

            return new FlowsealUpdateResult(
                version,
                "Официальный архив скачан и проверен по SHA-256. Он не устанавливался и не запускался.",
                archivePath);
        }

        public static string OfficialReleasePage => ReleasePageUrl;

        private static HttpClient CreateHttpClient()
        {
            var client = new HttpClient
            {
                Timeout = TimeSpan.FromMinutes(3)
            };
            client.DefaultRequestHeaders.UserAgent.Add(
                new ProductInfoHeaderValue("NoDPI", "1.0"));
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
            return client;
        }

        private static JsonElement FindZipAsset(JsonElement release)
        {
            if (!release.TryGetProperty("assets", out JsonElement assets) ||
                assets.ValueKind != JsonValueKind.Array)
            {
                throw new InvalidDataException("GitHub не вернул список файлов релиза.");
            }

            foreach (JsonElement asset in assets.EnumerateArray())
            {
                string name = asset.TryGetProperty("name", out JsonElement nameElement)
                    ? nameElement.GetString() ?? string.Empty
                    : string.Empty;

                if (name.StartsWith("zapret-discord-youtube-", StringComparison.OrdinalIgnoreCase) &&
                    name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                {
                    return asset;
                }
            }

            throw new InvalidDataException("В официальном релизе не найден ZIP-архив Flowseal.");
        }

        private static string GetRequiredString(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property) &&
                property.ValueKind == JsonValueKind.String &&
                !string.IsNullOrWhiteSpace(property.GetString()))
            {
                return property.GetString()!;
            }

            throw new InvalidDataException($"В метаданных релиза отсутствует поле {propertyName}.");
        }

        private static string ParseSha256Digest(string digest)
        {
            const string prefix = "sha256:";
            if (!digest.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("У архива нет SHA-256 в метаданных GitHub.");

            string hash = digest[prefix.Length..];
            if (hash.Length != 64 || !IsHex(hash))
                throw new InvalidDataException("GitHub вернул некорректную SHA-256 сумму.");

            return hash;
        }

        private static bool IsHex(string value)
        {
            foreach (char character in value)
            {
                if (!Uri.IsHexDigit(character))
                    return false;
            }

            return true;
        }

        private static async Task DownloadAndVerifyAsync(
            Uri assetUri,
            string temporaryPath,
            long expectedSize,
            string expectedHash,
            CancellationToken cancellationToken)
        {
            using HttpResponseMessage response = await HttpClient.GetAsync(
                assetUri,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken);
            response.EnsureSuccessStatusCode();

            if (response.Content.Headers.ContentLength is long contentLength &&
                (contentLength != expectedSize || contentLength > MaximumArchiveSize))
            {
                throw new InvalidDataException("Размер загружаемого архива не совпадает с метаданными релиза.");
            }

            await using Stream input = await response.Content.ReadAsStreamAsync(cancellationToken);
            await using var output = new FileStream(
                temporaryPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                81920,
                useAsync: true);
            using IncrementalHash hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);

            byte[] buffer = new byte[81920];
            long totalBytes = 0;
            int bytesRead;
            while ((bytesRead = await input.ReadAsync(buffer.AsMemory(), cancellationToken)) > 0)
            {
                totalBytes += bytesRead;
                if (totalBytes > MaximumArchiveSize || totalBytes > expectedSize)
                    throw new InvalidDataException("Размер загружаемого архива превышает ожидаемый.");

                hash.AppendData(buffer, 0, bytesRead);
                await output.WriteAsync(buffer.AsMemory(0, bytesRead), cancellationToken);
            }

            if (totalBytes != expectedSize)
                throw new InvalidDataException("Загруженный архив имеет неполный размер.");

            string actualHash = Convert.ToHexString(hash.GetHashAndReset());
            if (!string.Equals(actualHash, expectedHash, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("SHA-256 архива не совпадает с официальными метаданными GitHub.");
        }

        private static async Task<string> ComputeFileSha256Async(
            string filePath,
            CancellationToken cancellationToken)
        {
            await using var stream = new FileStream(
                filePath,
                FileMode.Open,
                FileAccess.Read,
                FileShare.Read,
                81920,
                useAsync: true);
            byte[] hash = await SHA256.HashDataAsync(stream, cancellationToken);
            return Convert.ToHexString(hash);
        }
    }
}
