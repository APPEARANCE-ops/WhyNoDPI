﻿using System.Linq;
namespace NoDPI.Core
{
    public class StrategyManager
    {
        public string[] Strategies { get; } =
        {
            "Автоматическая",
            "Стандартная",
            "Мягкая",
            "Диагностическая"
        };

        public string CurrentStrategy { get; private set; }
            = "Автоматическая";

        public void Select(string strategy)
        {
            if (Strategies.Contains(strategy))
                CurrentStrategy = strategy;
        }
    }
}