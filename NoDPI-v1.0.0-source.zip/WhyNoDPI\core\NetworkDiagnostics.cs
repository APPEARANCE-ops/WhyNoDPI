﻿
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace NoDPI.Core
{
    public sealed record NetworkDiagnosticResult(
        bool IsReachable,
        string Summary,
        string Details);

    public class NetworkDiagnostics
    {
        private const string TestHost = "example.com";
        private static readonly TimeSpan CheckTimeout = TimeSpan.FromSeconds(5);

        public async Task<NetworkDiagnosticResult> CheckAsync()
        {
            if (!NetworkInterface.GetIsNetworkAvailable())
            {
                return new NetworkDiagnosticResult(
                    false,
                    "Нет сетевого подключения",
                    "Windows не обнаружила активный сетевой интерфейс.");
            }

            IPAddress[] addresses;
            using (var dnsTimeout = new CancellationTokenSource(CheckTimeout))
            {
                try
                {
                    addresses = await Dns.GetHostAddressesAsync(TestHost, dnsTimeout.Token);
                }
                catch (SocketException ex)
                {
                    return new NetworkDiagnosticResult(
                        false,
                        "Ошибка DNS",
                        $"Не удалось разрешить {TestHost}: {ex.Message}");
                }
                catch (OperationCanceledException)
                {
                    return new NetworkDiagnosticResult(
                        false,
                        "Тайм-аут DNS",
                        $"DNS-сервер не ответил за {CheckTimeout.TotalSeconds:0} секунд.");
                }
            }

            if (addresses.Length == 0)
            {
                return new NetworkDiagnosticResult(
                    false,
                    "Ошибка DNS",
                    $"Для {TestHost} не найдено IP-адресов.");
            }

            using var client = new TcpClient();
            using var connectionTimeout = new CancellationTokenSource(CheckTimeout);

            try
            {
                await client.ConnectAsync(TestHost, 443, connectionTimeout.Token);
                return new NetworkDiagnosticResult(
                    true,
                    "Контрольный узел доступен",
                    $"DNS работает; TCP-подключение к {TestHost}:443 успешно.");
            }
            catch (SocketException ex)
            {
                return new NetworkDiagnosticResult(
                    false,
                    "Контрольный узел недоступен",
                    $"DNS работает, но TCP-подключение к {TestHost}:443 не удалось: {ex.Message}");
            }
            catch (OperationCanceledException)
            {
                return new NetworkDiagnosticResult(
                    false,
                    "Тайм-аут подключения",
                    $"Узел {TestHost}:443 не ответил за {CheckTimeout.TotalSeconds:0} секунд.");
            }
        }
    }
}
