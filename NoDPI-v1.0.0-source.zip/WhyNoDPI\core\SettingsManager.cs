﻿
using System;
using System.IO;
using System.Text.Json;

namespace NoDPI.Core
{
    public class SettingsManager
    {
        private readonly string folderPath;
        private readonly string filePath;

        public bool AutoStart { get; set; }
        public bool MinimizeToTray { get; set; }

        public string CurrentStrategy { get; set; }
            = "Автоматическая";

        public SettingsManager()
        {
            folderPath = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "NoDPI"
            );

            filePath = Path.Combine(folderPath, "settings.json");
        }

        public void Save()
        {
            Directory.CreateDirectory(folderPath);

            string json = JsonSerializer.Serialize(
                this,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });

            File.WriteAllText(filePath, json);
        }

        public void Load()
        {
            if (!File.Exists(filePath))
                return;

            string json = File.ReadAllText(filePath);

            SettingsManager? saved =
                JsonSerializer.Deserialize<SettingsManager>(json);

            if (saved == null)
                throw new InvalidDataException("Файл настроек пуст или содержит некорректные данные.");

            AutoStart = saved.AutoStart;
            MinimizeToTray = saved.MinimizeToTray;
            CurrentStrategy = saved.CurrentStrategy ?? "Автоматическая";
        }
    }
}
