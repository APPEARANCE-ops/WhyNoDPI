﻿
using Microsoft.Win32;
using System;

namespace NoDPI.Core
{
    public class StartupManager
    {
        private const string RunKey =
            @"Software\Microsoft\Windows\CurrentVersion\Run";

        private const string AppName = "NoDPI";

        public void SetEnabled(bool enabled)
        {
            using RegistryKey key =
                Registry.CurrentUser.OpenSubKey(RunKey, true)
                ?? Registry.CurrentUser.CreateSubKey(RunKey)
                ?? throw new InvalidOperationException(
                    "Не удалось открыть раздел автозапуска Windows.");

            if (!enabled)
            {
                key.DeleteValue(AppName, false);
                return;
            }

            string exePath = Environment.ProcessPath
                ?? throw new InvalidOperationException(
                    "Не удалось определить путь к исполняемому файлу.");

            if (string.IsNullOrWhiteSpace(exePath))
                throw new InvalidOperationException(
                    "Путь к исполняемому файлу пуст.");

            key.SetValue(AppName, $"\"{exePath}\"", RegistryValueKind.String);
        }
    }
}
