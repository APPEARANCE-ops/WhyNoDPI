﻿
using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NoDPI.Core;

namespace NoDPI
{
    public partial class MainWindow : Window
    {
        private bool isLoadingSettings = true;

        private readonly StrategyManager strategyManager = new();
        private readonly NetworkDiagnostics diagnostics = new();
        private readonly SettingsManager settings = new();
        private readonly StartupManager startupManager = new();
        private readonly FlowsealUpdateManager flowsealUpdateManager = new();
        private readonly AppUpdateManager appUpdateManager = new();
        private string? flowsealArchivePath;

        public MainWindow()
        {
            InitializeComponent();

            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                settings.Load();
            }
            catch (Exception ex)
            {
                AddLog("Не удалось загрузить настройки: " + ex.Message);
            }

            try
            {
                startupManager.SetEnabled(settings.AutoStart);
            }
            catch (Exception ex)
            {
                AddLog("Не удалось применить автозапуск Windows: " + ex.Message);
            }

            strategyManager.Select(settings.CurrentStrategy);
            settings.CurrentStrategy = strategyManager.CurrentStrategy;
            AutoStartBox.IsChecked = settings.AutoStart;
            TrayBox.IsChecked = settings.MinimizeToTray;

            foreach (var item in StrategyBox.Items)
            {
                if (item is ComboBoxItem strategyItem &&
                    string.Equals(
                        strategyItem.Content?.ToString(),
                        strategyManager.CurrentStrategy,
                        StringComparison.Ordinal))
                {
                    StrategyBox.SelectedItem = strategyItem;
                    break;
                }
            }

            isLoadingSettings = false;

            AddLog("NoDPI запущен");
            AddLog("Интерфейс готов");
            CurrentStrategy.Text = strategyManager.CurrentStrategy;

            try
            {
                await UpdateNetworkStatusAsync();
            }
            catch (Exception ex)
            {
                StatusText.Text = "Ошибка проверки";
                StatusText.Foreground = Brushes.Salmon;
                ModuleStatus.Text = ex.Message;
                AddLog("Ошибка проверки сети: " + ex.Message);
            }

            await CheckAppUpdateAsync();
            await CheckFlowsealUpdateAsync();
        }

        private async Task UpdateNetworkStatusAsync()
        {
            NetworkDiagnosticResult result = await diagnostics.CheckAsync();
            StatusText.Text = result.Summary;
            StatusText.Foreground = result.IsReachable
                ? Brushes.LightGreen
                : Brushes.Salmon;
            ModuleStatus.Text = result.Details;
            AddLog(result.Details);
        }

        private void ShowPage(Grid page, string name)
        {
            HomePage.Visibility = Visibility.Collapsed;
            StrategiesPage.Visibility = Visibility.Collapsed;
            JournalPage.Visibility = Visibility.Collapsed;
            SettingsPage.Visibility = Visibility.Collapsed;
            UpdatesPage.Visibility = Visibility.Collapsed;

            page.Visibility = Visibility.Visible;

            AddLog("Открыта страница: " + name);
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            ShowPage(HomePage, "Главная");
        }

        private void Strategies_Click(object sender, RoutedEventArgs e)
        {
            ShowPage(StrategiesPage, "Стратегии");
        }

        private void Journal_Click(object sender, RoutedEventArgs e)
        {
            ShowPage(JournalPage, "Журнал");
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            ShowPage(SettingsPage, "Настройки");
        }

        private void Updates_Click(object sender, RoutedEventArgs e)
        {
            ShowPage(UpdatesPage, "Обновления");
        }

        private async void AppUpdate_Click(object sender, RoutedEventArgs e)
        {
            await CheckAppUpdateAsync();
        }

        private async Task CheckAppUpdateAsync()
        {
            AppUpdateButton.IsEnabled = false;
            AppUpdateStatus.Text = "Проверяю GitHub Releases NoDPI...";

            try
            {
                AppUpdateResult result = await appUpdateManager.CheckLatestAsync();
                AppUpdateStatus.Text = result.Status;
                AppUpdateStatus.Foreground = result.IsUpdateAvailable
                    ? Brushes.Gold
                    : Brushes.LightGreen;
                AddLog(result.Status);
            }
            catch (Exception ex)
            {
                AppUpdateStatus.Text = "Не удалось проверить обновления NoDPI: " + ex.Message;
                AddLog("Проверка обновлений NoDPI не удалась: " + ex.Message);
            }
            finally
            {
                AppUpdateButton.IsEnabled = true;
            }
        }

        private void OpenAppRelease_Click(object sender, RoutedEventArgs e)
        {
            OpenOfficialPage(
                AppUpdateManager.OfficialReleasePage,
                "страницу релизов NoDPI");
        }

        private async void FlowsealUpdate_Click(object sender, RoutedEventArgs e)
        {
            await CheckFlowsealUpdateAsync();
        }

        private async Task CheckFlowsealUpdateAsync()
        {
            FlowsealUpdateButton.IsEnabled = false;
            FlowsealOpenArchiveButton.IsEnabled = false;
            FlowsealUpdateStatus.Text = "Проверяю последний релиз Flowseal на GitHub...";
            FlowsealUpdatePath.Text = string.Empty;
            flowsealArchivePath = null;

            try
            {
                FlowsealUpdateResult result =
                    await flowsealUpdateManager.CheckAndDownloadLatestAsync();
                FlowsealUpdateStatus.Text = $"Версия {result.Version}: {result.Status}";
                FlowsealUpdatePath.Text = result.ArchivePath;
                flowsealArchivePath = result.ArchivePath;
                FlowsealOpenArchiveButton.IsEnabled = true;
                AddLog($"Flowseal {result.Version}: {result.Status}");
            }
            catch (Exception ex)
            {
                FlowsealUpdateStatus.Text = "Проверка или загрузка не удалась: " + ex.Message;
                AddLog("Обновление Flowseal не удалось: " + ex.Message);
            }
            finally
            {
                FlowsealUpdateButton.IsEnabled = true;
            }
        }

        private void OpenFlowsealRelease_Click(object sender, RoutedEventArgs e)
        {
            OpenOfficialPage(
                FlowsealUpdateManager.OfficialReleasePage,
                "страницу официальных релизов Flowseal");
        }

        private void OpenOfficialPage(string? url, string pageDescription)
        {
            if (string.IsNullOrWhiteSpace(url))
                return;

            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                AddLog($"Не удалось открыть {pageDescription}: {ex.Message}");
            }
        }

        private void OpenFlowsealArchive_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(flowsealArchivePath) ||
                !File.Exists(flowsealArchivePath))
            {
                FlowsealOpenArchiveButton.IsEnabled = false;
                AddLog("Скачанный архив не найден.");
                return;
            }

            string? directory = Path.GetDirectoryName(flowsealArchivePath);
            if (string.IsNullOrWhiteSpace(directory))
            {
                AddLog("Не удалось определить папку скачанного архива.");
                return;
            }

            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = directory,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                AddLog("Не удалось открыть папку архива: " + ex.Message);
            }
        }

        private async void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleButton.IsEnabled = false;
            StatusText.Text = "Проверка сети...";
            ModuleStatus.Text = "Проверяем DNS и подключение к интернету";

            try
            {
                await UpdateNetworkStatusAsync();
            }
            catch (Exception ex)
            {
                StatusText.Text = "Ошибка проверки";
                StatusText.Foreground = Brushes.Salmon;
                ModuleStatus.Text = ex.Message;
                AddLog("Ошибка проверки сети: " + ex.Message);
            }
            finally
            {
                ToggleButton.IsEnabled = true;
            }
        }

        private void StrategyBox_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (StrategyBox?.SelectedItem is ComboBoxItem item)
            {
                string strategy =
                    item.Content?.ToString() ?? "Автоматическая";

                strategyManager.Select(strategy);

                if (CurrentStrategy != null)
                    CurrentStrategy.Text = strategy;

                if (StrategyDescription != null)
                {
                    StrategyDescription.Text =
                        "Выбран профиль: " + strategy +
                        ". Профиль пока не меняет параметры сетевого подключения.";
                }

                settings.CurrentStrategy = strategyManager.CurrentStrategy;
                if (!isLoadingSettings && SaveSettings())
                    AddLog("Выбран профиль: " + strategy);
            }
        }

        private bool SaveSettings()
        {
            try
            {
                settings.Save();
                return true;
            }
            catch (Exception ex)
            {
                AddLog("Не удалось сохранить настройки: " + ex.Message);
                return false;
            }
        }

        private void AddLog(string message)
        {
            if (LogList == null)
                return;

            LogList.Items.Insert(
                0,
                $"[{DateTime.Now:HH:mm:ss}] {message}"
            );
        }

        private void ClearLog_Click(object sender, RoutedEventArgs e)
        {
            LogList.Items.Clear();
            AddLog("Журнал очищен");
        }

        private void SettingChanged(object sender, RoutedEventArgs e)
        {
            if (isLoadingSettings || sender is not CheckBox box)
                return;

            string name = box.Content?.ToString() ?? "Настройка";
            bool value = box.IsChecked == true;
            bool previousValue = box == AutoStartBox
                ? settings.AutoStart
                : settings.MinimizeToTray;

            if (box == AutoStartBox)
            {
                try
                {
                    startupManager.SetEnabled(value);
                }
                catch (Exception ex)
                {
                    SetCheckboxValue(box, previousValue);
                    AddLog("Не удалось изменить автозапуск Windows: " + ex.Message);
                    return;
                }

                settings.AutoStart = value;
            }
            else if (box == TrayBox)
            {
                settings.MinimizeToTray = value;
            }

            if (!SaveSettings())
            {
                if (box == AutoStartBox)
                {
                    settings.AutoStart = previousValue;
                    try
                    {
                        startupManager.SetEnabled(previousValue);
                    }
                    catch (Exception ex)
                    {
                        AddLog("Не удалось отменить изменение автозапуска: " + ex.Message);
                    }
                }
                else
                {
                    settings.MinimizeToTray = previousValue;
                }

                SetCheckboxValue(box, previousValue);
                return;
            }

            AddLog(name + ": " + (value ? "Включено" : "Выключено"));
        }

        private void SetCheckboxValue(CheckBox box, bool value)
        {
            isLoadingSettings = true;
            box.IsChecked = value;
            isLoadingSettings = false;
        }
    }
}
