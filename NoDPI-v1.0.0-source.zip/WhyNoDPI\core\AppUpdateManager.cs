using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace NoDPI.Core
{
    public sealed record AppUpdateResult(
        string Status,
        bool IsUpdateAvailable);

    public sealed class AppUpdateManager
    {
        private const string ReleaseApiUrl =
            "https://api.github.com/repos/APPEARANCE-ops/WhyNoDPI/releases/latest";
        private const string ReleasePageUrl =
            "https://github.com/APPEARANCE-ops/WhyNoDPI/releases";
        private static readonly HttpClient HttpClient = CreateHttpClient();

        public async Task<AppUpdateResult> CheckLatestAsync(
            CancellationToken cancellationToken = default)
        {
            using HttpResponseMessage response = await HttpClient.GetAsync(
                ReleaseApiUrl,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken);

            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return new AppUpdateResult(
                    "Релиз не найден или репозиторий недоступен. Проверьте публичность репозитория и публикацию первого Release.",
                    false);
            }

            response.EnsureSuccessStatusCode();
            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            using JsonDocument document = await JsonDocument.ParseAsync(
                stream,
                cancellationToken: cancellationToken);

            JsonElement release = document.RootElement;
            string tag = GetRequiredString(release, "tag_name");
            Version latestVersion = ParseVersion(tag);
            Version currentVersion = typeof(AppUpdateManager).Assembly.GetName().Version
                ?? new Version(1, 0, 0);
            bool updateAvailable = latestVersion > currentVersion;
            string status = updateAvailable
                ? $"Доступна новая версия NoDPI: {latestVersion} (установлена {currentVersion})."
                : $"Установлена актуальная версия NoDPI: {currentVersion}.";

            return new AppUpdateResult(status, updateAvailable);
        }

        public static string OfficialReleasePage => ReleasePageUrl;

        private static HttpClient CreateHttpClient()
        {
            var client = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(15)
            };
            client.DefaultRequestHeaders.UserAgent.Add(
                new ProductInfoHeaderValue("NoDPI", "1.0"));
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
            return client;
        }

        private static string GetRequiredString(JsonElement element, string propertyName)
        {
            if (element.TryGetProperty(propertyName, out JsonElement property) &&
                property.ValueKind == JsonValueKind.String &&
                !string.IsNullOrWhiteSpace(property.GetString()))
            {
                return property.GetString()!;
            }

            throw new InvalidOperationException(
                $"В метаданных GitHub Release отсутствует поле {propertyName}.");
        }

        private static Version ParseVersion(string tag)
        {
            string versionText = tag.StartsWith("v", StringComparison.OrdinalIgnoreCase)
                ? tag[1..]
                : tag;

            if (Version.TryParse(versionText, out Version? version))
                return version;

            throw new InvalidOperationException(
                $"Тег релиза '{tag}' не является корректной версией (ожидается, например, v1.2.3).");
        }
    }
}
